package com.example.ugr.museo;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

import ai.api.AIListener;
import ai.api.android.AIConfiguration;
import ai.api.android.AIService;
import ai.api.model.AIError;
import ai.api.model.AIResponse;
import ai.api.model.Result;

public class Menu_animales extends AppCompatActivity implements AIListener {

    private AIService aiService;
    private TextToSpeech speaker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_animales);

        final AIConfiguration config = new AIConfiguration("23e6b35921f14ffeac0dfd9724403d75",
                AIConfiguration.SupportedLanguages.Spanish,
                AIConfiguration.RecognitionEngine.System);
        aiService = AIService.getService(this, config);
        aiService.setListener(this);

        speaker = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

            }
        });
        speaker.setPitch(2);
        speaker.setSpeechRate(2);


    }

    public void listenButtonOnClick(final View view) {
        ChequearPermisoAudio();

        speaker.stop();

        ConnectivityManager cm = (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

        if (activeNetwork  == null) {
            speaker.speak("Por favor conéctate a internet", TextToSpeech.QUEUE_ADD, null, "msg");
        }
        else {
            aiService.startListening();
        }
    }

    @Override
    public void onResult(AIResponse response) {
        Result result = response.getResult();
        speaker.speak(result.getFulfillment().getSpeech(), TextToSpeech.QUEUE_FLUSH, null, null);

    }

    @Override
    public void onError(AIError error) {

    }

    @Override
    public void onAudioLevel(float level) {

    }

    @Override
    public void onListeningStarted() {

    }

    @Override
    public void onListeningCanceled() {

    }

    @Override
    public void onListeningFinished() {

    }

    @Override
    public void onDestroy() {
        if (speaker.isSpeaking())
            speaker.stop();
        speaker.shutdown();

        super.onDestroy();
    }

    public void ChequearPermisoAudio() {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO},
                    22);
        }
    }






    public void Lemur_llamar(View view) {
        Intent intent = new Intent(this, Animal.class);
        Bundle b = new Bundle();
        ArrayList<String> Animal1 = new ArrayList<String>();
        Animal1.add("lemur");
        Animal1.add("lemuretiquetas");
        Animal1.add("Es un primate de hábitos estrictamente diurnos que pasa la mayor parte del tiempo en los árboles, aunque también frecuenta el suelo. Es sociable y vive en grupos de 5 a 25 individuos. Es polígamo y usa su característica cola para hacer señales visuales y odoríferas. Cuando camina por el suelo mantiene erguida la cola para señalar su presencia al resto de sus congéneres. También se comunica por vocalizaciones, por actitudes corporales y por expresiones del rostro. Se alimenta de frutos, hojas, flores, cortezas y pequeños insectos.");

        b.putStringArrayList("key",Animal1 );
        intent.putExtras(b);
        startActivity(intent);
    }


    public void Nutria_llamar(View view) {
        Intent intent = new Intent(this, Animal.class);
        Bundle b = new Bundle();
        ArrayList<String> Animal1 = new ArrayList<String>();
        Animal1.add("nutria");
        Animal1.add("nutriaetiquetas");
        Animal1.add("Es un animal muy sociable que vive en grupos familiares. Es monógama. Dedica gran parte del día a jugar y comunicarse entre ellas. Se han identificado hasta doce vocalizaciones diferentes además de señales visuales, hormonales y táctiles, como el acicalamiento social. Tiene gran agilidad en sus manos que las utiliza para cazar cangrejos, moluscos y peces por el tacto, levantar piedras o construir madrigueras en las orillas de los ríos.");

        b.putStringArrayList("key",Animal1 );
        intent.putExtras(b);
        startActivity(intent);
    }

}
